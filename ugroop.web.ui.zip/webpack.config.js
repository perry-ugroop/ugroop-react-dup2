

var webpack = require("webpack");
var path = require("path");

var DIST_DIR = path.resolve(__dirname,"dist");
var SRC_DIR = path.resolve(__dirname,"src"); 

// require("/css/bootstrap.css");
// require("/css/ugstyle.css");

var publicPath = 'http://localhost:8080';
var config = {
     entry: SRC_DIR + "/components/index.js",  
    /*entry: {
        home: './src/components/index.js',
        login: './src/components/login.js',
        register: './src/components/register.js'
    },    */       
    output: {
        path: DIST_DIR + "/components",
        filename: "bundle.js",
        publicPath: "/components/"
    },
    module: {
        loaders: [
            { test: /\.js$/, include: SRC_DIR, loader: "babel-loader", query: { presets: ["react","es2015","stage-2"] }},
            { test: /\.css$/, loader: "style-loader!css-loader" },
            { test: /\.png$/, loader: "url-loader?limit=100000" },
            { test: /\.jpg$/, loader: "file-loader" }           
        ]
    }
};

module.exports = config;

