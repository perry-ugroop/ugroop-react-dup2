require("bootstrap-webpack!./bootstrap.config.js");

module.exports = {
    scripts: {

    },
    styles: {

    }
};