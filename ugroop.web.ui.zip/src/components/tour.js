console.log("Tour Loaded");

import React from "react";
import { render } from "react-dom";
import { Router, Route, browserHistory} from "react-router";
import { Button } from 'react-bootstrap';


import {Routes} from "../components/routes/Route";
import {Root} from "../components/routes/Root";
import {Home} from "../components/common/Home";
import {User} from "../components/common/User";
import {Header} from "../components/common/Header";
import {Slider} from "../components/common/Slider";



console.log("index.js loaded");

class App extends React.Component {
    render(){
        return (     
                  
           <div className="container">   
         
                <Header/>
                <Slider/>
                <Home/>
           </div>
        );
    }
}

render(<App/>, window.document.getElementById("app"));
