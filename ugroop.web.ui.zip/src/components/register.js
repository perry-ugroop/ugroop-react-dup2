import React from "react";
import { render } from "react-dom";
import { Router, Route, browserHistory, Link} from "react-router";


import {Login} from "../components/common/Register";

export class Register extends React.Component{
    render(){
        return (                
                <div>
                    <Register />                 
                </div>               
        );
    }
}


render(<Register/>, window.document.getElementById("app"));