import React from "react";
import {Slider} from "../common/Slider";
import {ClientList} from "../home/ClientList";

export class HomeIndex extends React.Component{    
    render(){        
        return (
            <div>
            <Slider />
            <ClientList />
            </div>
        );
    }
}
