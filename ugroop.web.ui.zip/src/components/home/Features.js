import React, {Component} from 'react'
import { render } from "react-dom";

console.log('Features Loaded');

export class Features extends Component { 
  render () {
    return (
         <div className="subpages-body-content container">
        <div className="row">
            <div className="col-md-6">
                <div className="icon-features icon-feature-one">
                    <h3 className="featured-header">Feature One</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-two">
                    <h3 className="featured-header">Feature Two</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-three">
                    <h3 className="featured-header">Feature Three</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-four">
                    <h3 className="featured-header">Feature Four</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-five">
                    <h3 className="featured-header">Feature five</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-six">
                    <h3 className="featured-header">Feature Six</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-seven">
                    <h3 className="featured-header">Feature Seven</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
            <div className="col-md-6">
                <div className="icon-features icon-feature-eight">
                    <h3 className="featured-header">Feature Eight</h3>
                    <p>Donec id elit non mi porta eget metus. ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                </div>
            </div>
        </div>
    </div>
    )
  }
}