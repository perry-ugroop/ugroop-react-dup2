import React from "react";

export class ClientList extends React.Component{
    render(){
        return (
        <div className="clients">
            <div className="container">
                <h1>Our Clients</h1>
                <ul className="client-logo fademe">
                    <li><img src="../../images/logo/logo-school-1.png" width="131" height="132" /></li>
                    <li><img src="../../images/logo/logo-school-2.png" width="131" height="132" /></li>
                    <li><img src="../../images/logo/logo-school-3.png" width="131" height="132" /></li>
                    <li><img src="../../images/logo/logo-school-4.png" width="131" height="132" /></li>
                    <li><img src="../../images/logo/logo-school-5.png" width="131" height="132" /></li>
                    <li><img src="../../images/logo/logo-school-6.png" width="131" height="132" /></li>
                    <li><img src="../../images/logo/logo-school-7.png" width="131" height="132" /></li>
                </ul>
            </div>
        </div>       
        );
    }
}