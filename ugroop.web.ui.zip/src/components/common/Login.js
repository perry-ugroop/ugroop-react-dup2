import React, {Component} from 'react'
import loginStyles from '../common/Login.css'

export class Login extends Component { 
  render () {
    return (
      <div className="container ug-login-body">
      <div className="row">
        <div className="ug-login-panel ug-flat-border">
          <div className="ug-panel-body">
            <h1 className="ug-logo"><img src="images/logo-ugroop.png" alt="ügroop" /></h1>
            <div className="ug-oauth-wrapper">
            	<h1 className="ug-oauth-title"><p><span>Sign in via</span></p></h1>              
                <ul className="ug-oauth-icon-list"> 
                    <li className="ug-facebook-oauth"><a href="#" data-toggle="tooltip" data-placement="top" title="Sign in using Facebook"><img src="images/icon-facebook-transparent.png" width="50" height="50" alt="Sign In with Facebook" /></a></li>                  
                    <li className="ug-twitter-oauth"><a href="#" data-toggle="tooltip" data-placement="top" title="Sign in using Twitter"><img src="images/icon-twitter-transparent.png" width="50" height="50" alt="Sign In with Twitter" /></a></li>
                    <li className="ug-yahoo-oauth"><a href="#" data-toggle="tooltip" data-placement="top" title="Sign in using Yahoo"><img src="../../images/icon-yahoo-transparent.png" width="50" height="50" alt="Sign In with Yahoo" /></a></li>
                    <li className="ug-googleplus-oauth"><a href="#" data-toggle="tooltip" data-placement="top" title="Sign in using Google+"><img src="../../images/icon-googleplus-transparent.png" width="50" height="50" alt="Sign In with Google+" /></a></li>
                </ul>
            </div>
            <h1 className="ug-or-oauth"><p><span>OR</span></p></h1>            
            <form method="post" action="">
            	<div className="alert alert-danger" role="alert">Error message here!</div>                                
                <div className="input-group input-group-md">
                      <span className="input-group-addon ug-flat-border"><i class="glyphicon glyphicon-user"></i></span>
                      <input id="login-username" type="text" className="form-control ug-flat-border" name="username" value="" placeholder="username or email" />                                        
                  </div>
                  <div className="input-group input-group-md">
                      <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-lock"></i></span>
                      <input id="login-password" type="password" className="form-control ug-flat-border" name="password" placeholder="password" />
                  </div>                                                                                                                        
                  <button type="submit" className="btn btn-primary btn-block ug-flat-border ug-btn-sign" >Sign In</button> 
                  <div className="form-group clearfix ug-login-footer-link">
                    <div className="checkbox ug-input-remember">
                      <label>
                        <input id="login-remember" type="checkbox" name="remember" value="1" /> Remember me
                      </label>           
                    </div> 
                    <p className="ug-link-lost-password"><a href="#">Forgot your password?</a></p> 
                  </div>
                  <p className="ug-link-signup">Don't have an account? <a href="#">Sign up</a></p>   
            </form>            	
          </div>
        </div>     
      </div>
    </div>
    )
  }
}