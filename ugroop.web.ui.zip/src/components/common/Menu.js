import React from "react";

export class Menu extends React.Component{
    render(){
        return (
            <div>
                <h3>Menu</h3>
            </div>        
        );
    }
}