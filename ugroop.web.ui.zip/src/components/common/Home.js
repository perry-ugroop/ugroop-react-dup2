import React from "react";
import { Router, Route, browserHistory, Link} from "react-router";
export class Home extends React.Component{
    render(){
        return (
            <div>
                    Test
            </div>  
        );
    }
}