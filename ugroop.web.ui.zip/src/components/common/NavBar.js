import React from "react";
import {} from '../common/NavBar.css'

export class NavigationBar extends React.Component{
    render(){
        return (
            <div className="nav-wrapper">                           
                <nav className="navbar navbar-default" role="navigation">
                    <div className="container">
                        <div className="navbar-header">
                            <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span className="sr-only">Toggle navigation</span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                            <a className="navbar-brand" href="https://www.ugroop.com"><img src="../../images/logo-ugroop.png" width="210" height="67" alt="Ugroop"/></a>
                        </div>
                        <div id="navbar" className="navbar-collapse collapse navbar-right nav-admin">
                            <ul className="nav navbar-nav">                          
                            <li className="active"><a href="~/">Home</a></li>
                            <li><a href="Features">Features</a></li>
                            <li><a href="Pricing">Pricing</a></li>
                            <li><a href="Blog">Blog</a></li>
                            <li><a href="Faq">FAQ</a></li>
                            <li><a href="ContactUs">Contact Us</a></li>
                            <li><a href="Registration" class="navbar-btn nav-button curveside">Register</a></li>
                            <li><a href="Login">Sign in</a></li>
                        </ul>
                        </div>
                    </div>
                </nav>
            </div>        
        );
    }
}

