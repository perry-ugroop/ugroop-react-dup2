import React from "react";
import {Title} from "../common/Title";
import { Router, Route, browserHistory, Link} from "react-router";

export class Subheader extends React.Component{
    render(){
        return (
            <div className="subpages-header">
                <div className="container subpages-header-around-the-world">
                    <h1 className="icon-title-pricing">Pricing</h1>
                </div>
            </div>
        );
    }
}