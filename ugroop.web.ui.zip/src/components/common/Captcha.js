import React, {Component} from 'react'

export class Captcha extends Component { 
  render () {
    return (
       <div className="Captcha">
                Registration Captcha
       </div>
    )
  }
}