import React from "react";

export class Title extends React.Component{
    render(){
        return (                
                <div className="container">
                    <div className="navbar-header">
                        <a class="navbar-brand" href="/">                      
                            <img src="../../images/logo-ugroop.png" width="189" height="67" alt="Ugroop" />
                        </a>
                    </div>                 
                </div>               
        );
    }
}