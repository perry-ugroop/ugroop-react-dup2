import React from "react";
import {Captcha} from "../common/Captcha";


export class Registration extends React.Component{ 
    render(){
        return (           
                <div className="container ug-login-body">
                    <div className="row">
                        <div className="ug-login-panel-wide ug-flat-border">   

                         <h1 class="ug-logo"><img src="../../images/logo-ugroop.png" alt="ügroop" /></h1>
                        <div class="ug-oauth-wrapper">
                            <h1 class="ug-oauth-title"><p><span>Registration</span></p></h1>
                        </div>

                        <form className="registrationForm">  
                            {/* First Row */}
                            <div className="row">                                
                                 <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-chevron-right"></i></span>                           
                                        <input type="text" name="SchoolName" className="form-control ug-flat-border" placeholder = "School Name" />                        
                                    </div>                                
                                </div>
                                <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-chevron-right"></i></span>                           
                                        <input type="text" name="SchoolAddress" className="form-control ug-flat-border" placeholder = "Address" />                        
                                    </div>                                
                                </div>
                            </div>

                            {/* Second Row */}
                            <div className="row">                                
                                 <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon  glyphicon-user"></i></span>                           
                                        <input type="text" name="FirstName" className="form-control ug-flat-border" placeholder = "First Name" />                        
                                    </div>                                
                                </div>
                                <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon  glyphicon-user"></i></span>                           
                                        <input type="text" name="LastName" className="form-control ug-flat-border" placeholder = "Last Name" />                        
                                    </div>                                
                                </div>
                            </div>


                            {/* Third Row */}
                            <div className="row">                                
                                 <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-chevron-right"></i></span>                           
                                        <input type="text" name="Position" className="form-control ug-flat-border" placeholder = "Position" />                        
                                    </div>                                
                                </div>
                                <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-globe"></i></span>                           
                                        <input type="text" name="Website" className="form-control ug-flat-border" placeholder = "Website" />                        
                                    </div>                                
                                </div>
                            </div>

                            {/* Fourth Row */}
                            <div className="row">                                
                                 <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-phone-alt"></i></span>                           
                                        <input type="text" name="Telephone" className="form-control ug-flat-border" placeholder = "Telephone" />                        
                                    </div>                                
                                </div>
                                <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-envelope"></i></span>                           
                                        <input type="text" name="Email" className="form-control ug-flat-border" placeholder = "Email" />                        
                                    </div>                                
                                </div>
                            </div>

                             {/* Fifth Row */}
                            <div className="row">                                
                                 <div className="col-md-6">
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-lock"></i></span>                           
                                        <input type="password" name="Password" className="form-control ug-flat-border" placeholder = "Create Password (8-20 characters)" />                        
                                    </div>    
                                    <div className="input-group">
                                        <span className="input-group-addon ug-flat-border"><i className="glyphicon glyphicon-lock"></i></span>                           
                                        <input type="password" name="ConfirmPassword" className="form-control ug-flat-border" placeholder = "Retype Password" />                        
                                    </div>                             
                                </div>
                                <div className="col-md-6">
                                    <div className="input-group">
                                       <Captcha />                      
                                    </div>                                
                                </div>
                            </div>
                            <div>
                                <input type="submit" className="btn btn-primary btn-block ug-flat-border ug-btn-sign" value="Register" />
                                <p className="ug-link-signup" style={{margintop: 20}}>By clicking Register, you accept the 
                                <a href="#">User Agreement</a>. We don't share your email address (<a href="#">more info</a>).</p>
                            </div>

                        </form>      
                        </div>  
                    </div>
                </div>        
        );
    }
}