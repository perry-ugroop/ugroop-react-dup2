import React from "react";
import {Title} from "../common/Title";
import { Router, Route, browserHistory, Link} from "react-router";

export class Header extends React.Component{
    render(){
        return (
            <div>
                <nav className="navbar yamm navbar-default navbar-fixed-top" role="navigation">
                    <div className="container">
                        <div className="navbar-header">
                            <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span className="sr-only">Toggle navigation</span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                            <a className="navbar-brand" href="/"><Title /></a>
                        </div>
                        <div id="navbar" className="navbar-collapse collapse navbar-right">
                            <ul className="nav navbar-nav">
                                <li><Link to="/">Home</Link></li>
                                <li><Link to="/Features">Features</Link></li>
                                <li><Link to="/Pricing">Pricing</Link></li>
                                <li><Link to="/Blog">Blog</Link></li>
                                <li><Link to="/Faq">Faq</Link></li>
                                <li><Link to="/Contacts">Contact Us</Link></li>
                                <li><Link to="/Registration"  className="navbar-btn nav-button curveside">Register</Link></li>
                                <li><Link to="/Login">Sign In</Link></li></ul>
                        </div>
                    </div>
                </nav>
                </div>
        );
    }
}