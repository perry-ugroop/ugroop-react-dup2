import React from "react";
import { Carousel } from 'react-bootstrap';
import { render } from "react-dom";

export class Slider extends React.Component{    
    render(){   
        return (
            <div id="da-slider" className="da-slider">
            <Carousel style={{'margin-top':'75px','background-color':'blue'}}>
                    <Carousel.Item>
                    <img src="../../images/slider/ugroop-family-school.png"/>
                    <Carousel.Caption>
                        <h2 style={{'text-transform':'uppercase'}}>MANAGE ALL YOUR SCHOOL STUDY TOURS</h2>
                         <p style={{'top':'150px !important'}}>ügroop – a one-stop-shop solution for group tours organisers, teachers, 
                        students, parents and relatives to quickly and efficiently plan, prepare and promote upcoming tours, easily 
                        communicate during the tour and finally evaluate the tour outcomes, issues and experiences.</p>
                    </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                    <img src="../../images/slider/ugroop-group-student-sufing-ugroop-site.png" alt="" />
                    <Carousel.Caption>
                        <h2 style={{'text-transform':'uppercase'}}>WORRY-FREE FAMILY</h2>
                        <p style={{'top':'150px !important'}}>ügroop – Understandably parents would be concerned about sending their child overseas; 
                        safety and security is foremost in everyone’s thoughts. The ability to keep track of where they are, what is happening, 
                        how things are going and just to stay in touch, from any device, is key to peace of mind.</p>
                    </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                    <img  alt="900x500" src="../../images/slider/ugroop-group-student-sufing-ugroop-site.png"/>
                    <Carousel.Caption>
                        <h3>Third slide label</h3>
                        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                    </Carousel.Caption>
                    </Carousel.Item>
                </Carousel>            
        </div>
        );
    }
}

