import React from "react";

export class MenuBar_Index extends React.Component{
    render(){
        return (
               
                        <ul className="nav navbar-nav">
                            <li className="active"><a href="~/">Home</a></li>
                            <li><a href="Features">Features</a></li>
                            <li><a href="Pricing">Pricing</a></li>
                            <li><a href="Blog">Blog</a></li>
                            <li><a href="Faq">FAQ</a></li>
                            <li><a href="ContactUs">Contact Us</a></li>
                            <li><a href="Registration" class="navbar-btn nav-button curveside">Register</a></li>
                            <li><a href="Login">Sign in</a></li>
                        </ul>
        );
    }
}

