import React from "react";
import { Router, Route, browserHistory} from "react-router";

console.log("Route executed");


class Routes extends React.Component {
    render(){
        return (  
            <Router history={browserHistory}>
                <Route path={"/"} component = {Index} >
                        <Route path="user" component={User} />
                        <Route path="home" component={Index} />
                        <Route path="tour" component={TourIndex} />
                </Route>                
           </Router>    
        );
    }
}