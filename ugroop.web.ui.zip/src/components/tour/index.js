import React from "react";
import { render } from "react-dom";

console.log("tour index.js loaded");

class tour extends React.Component {
    render(){
        return (  
          <div>Tour Index</div> 
        );
    }
}
