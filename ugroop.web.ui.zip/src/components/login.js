import React from "react";
import { render } from "react-dom";
import { Router, Route, browserHistory, Link} from "react-router";
import { Button } from 'react-bootstrap';

import {Login} from "../components/common/Login";

export class LoginEntry extends React.Component{
    render(){
        return (                
                <div>
                    <Login />                 
                </div>               
        );
    }
}


render(<LoginEntry/>, window.document.getElementById("app"));