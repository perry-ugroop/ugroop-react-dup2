import React from "react";
import { render } from "react-dom";
import { Router, Route, browserHistory, Link, IndexRoute} from "react-router";
import { Button } from 'react-bootstrap';

import {Title} from "../components/common/Title";
import {Login} from "../components/common/Login";
import {Home} from "../components/common/Home";
import {Registration} from "../components/common/Register";
import {Slider} from "../components/common/Slider";
import {Footer} from "../components/common/Footer";
import {NavigationBar} from "../components/common/NavBar";

import {HomeIndex} from "../components/home/Index";
import {Features} from "../components/home/Features";
import {Pricing} from "../components/home/Pricing";
import {Contacts} from "../components/home/Contacts";
import {Blog} from "../components/home/Blog";
import {Faq} from "../components/home/Faq";
import {ClientList} from "../components/home/ClientList";

import {Header} from "../components/common/Header";
import {Routes} from "../components/routes/Route";
import {User} from "../components/common/User";
import {Root} from "../components/routes/Root";
import {TourIndex} from "../components/tour/index";

console.log("index.js loaded");

// class App extends React.Component {
//     render(){
//         return (  
//             <div className="HomePage">  
//                 <div className="PageHeader">                        
//                     <ClientList/>
//                 </div>      
//             </div>
//         )
//     }
// }

// render(<App/>, window.document.getElementById("app"));

/*
    <ul className="nav navbar-nav">
    <li><Link to="/Home">Home</Link></li>
         <li><Link to="/login">Login</Link></li>
          <li><Link to="/UserRegistration">Register</Link></li>
    </ul>
*/


const App = React.createClass({
  render() {
    return (
        <div>
        <Header />
        {this.props.children || <HomeIndex /> }
        <Footer />
        </div>    
    )
  }
})

render((  
  <Router  history={browserHistory}>
    <Route path="/" component={App}> 
       <IndexRoute component={HomeIndex} />          
       <Route path="login" component={Login} />
       <Route path="Registration" component={Registration} />     
       <Route path="Features" component={Features} />   
       <Route path="Pricing" component={Pricing} />
       <Route path="Blog" component={Blog} />         
       <Route path="Faq" component={Faq} />
       <Route path="Contacts" component={Contacts} />   
       <Route path="tour" component={TourIndex} />     
    </Route>

  </Router>
), document.getElementById('app'))






